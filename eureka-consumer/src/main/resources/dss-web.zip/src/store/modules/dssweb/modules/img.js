
export default {
  namespaced: true,
  state: {
  },
  getters: {
    // activeSetting (state) {
    //   return state.list.find(theme => theme.name === state.activeName)
    // }
  },
  actions: {
    // set ({ state, commit, dispatch }, themeName) {
    //   return new Promise(async resolve => {
    //     // 检查这个主题在主题列表里是否存在
    //     state.activeName = state.list.find(e => e.name === themeName) ? themeName : state.list[0].name
    //     // 将 vuex 中的主题应用到 dom
    //     commit('dom')
    //     // 持久化
    //     await dispatch('d2admin/db/set', {
    //       dbName: 'sys',
    //       path: 'theme.activeName',
    //       value: state.activeName,
    //       user: true
    //     }, { root: true })
    //     // end
    //     resolve()
    //   })
    // },
  },
  mutations: {
    // dom (state) {
    //   document.body.className = `theme-${state.activeName}`
    // }
  },
};
