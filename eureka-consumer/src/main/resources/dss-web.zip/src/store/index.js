import Vue from 'vue';
import Vuex from 'vuex';

import dssweb from './modules/dssweb';

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    dssweb,
  },
});
