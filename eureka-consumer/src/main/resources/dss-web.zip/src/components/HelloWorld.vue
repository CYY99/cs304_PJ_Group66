<template>
  <el-container style=" border: 1px solid #eee">
    <el-aside width="300px" style="background-color: #FFF;margin:0 4px;padding:16px;
    ">
      <el-menu :default-openeds="['1', '2', '3','4', '5']">
        <el-submenu index="1">
          <template slot="title"><i class="el-icon-s-unfold"></i><span style="font-size:20px">select</span></template>
          <el-menu-item-group>
            <el-menu-item index="1-1" @click="show('userAccount')">Account</el-menu-item>
            <el-menu-item index="1-2" @click="show('membership')">Membership</el-menu-item>
            <el-menu-item index="1-3" @click="show('developer')">Developer</el-menu-item>
            <el-menu-item index="1-4" @click="show('game')" >Game</el-menu-item>

          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="2">
          <template slot="title"><i class="el-icon-upload"></i><span style="font-size:20px;wdith:30px;">insert</span></template>
          <el-menu-item-group>
           <el-menu-item index="1-1" @click="show('insertUserAccount')">Account</el-menu-item>
           <el-menu-item index="1-2" @click="show('insertMembership')">Membership</el-menu-item>
           <el-menu-item index="1-3" @click="show('insertDeveloper')">Geveloper</el-menu-item>
           <el-menu-item index="1-4" @click="show('insertGame')">Game</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="3">
          <template slot="title"><i class="el-icon-files"></i><span style="font-size:20px">Aggregation</span></template>
          <el-menu-item-group>
            <el-menu-item index="3-1" @click="show('aggregationAccount')">accountGroup</el-menu-item>
          </el-menu-item-group>
        </el-submenu>

        <el-submenu index="4">
          <template slot="title"><i class="el-icon-plus"></i><span style="font-size:20px">Join</span></template>
          <el-menu-item-group>
            <el-menu-item index="4-1" @click="show('joinTable')">joinTable</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        
        <el-submenu index="5">
          <template slot="title"><i class="el-icon-plus"></i><span style="font-size:20px">Division</span></template>
          <el-menu-item-group>
            <el-menu-item index="5-1" @click="show('division')">division</el-menu-item>
          </el-menu-item-group>
        </el-submenu>

      </el-menu>
    </el-aside>
    
    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>check</el-dropdown-item>
            <el-dropdown-item>add</el-dropdown-item>
            <el-dropdown-item>delete</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span>admin</span>
      </el-header>
      
      <el-main>
        <div v-if="showOfName == 'userAccount'">
          <div style="background-color: #FFF;padding:16px;margin:8px 0;">
            <H2>selection</H2>
            <el-row>
              <el-col :span="2" style="margin:10px">age:</el-col>
              <el-col :span="16">
                <el-slider
                  @change="changeAccoUntFilter"
                  v-model="ageValue"
                  range
                  show-stops
                  :max="100">
                </el-slider>
              </el-col>
            </el-row>
            <el-row style="margin:16px 0">
              <el-col :span="2">gender:</el-col>
              <el-col :span="4">
                <el-checkbox-group @change="changeAccoUntFilter" v-model="genderValue" style="float: left;">
                  <el-checkbox label="male"></el-checkbox>
                  <el-checkbox label="female"></el-checkbox>
                </el-checkbox-group>
              </el-col>
            </el-row>
          </div>
          
          <el-table :data="tableData" >
            <el-table-column prop="accountId" label="accountID" >
            </el-table-column>
            <el-table-column prop="accountName" label="accountName">
            </el-table-column>
            <el-table-column prop="gender" label="gender" >
            </el-table-column>
            <el-table-column prop="registerDate" label="registerDate">
            </el-table-column>
            <el-table-column prop="birthDate" label="birthDate">
            </el-table-column>
            <el-table-column prop="age" label="age">
            </el-table-column>
            <el-table-column label="operating">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="editAccount(scope.$index, scope.accountID)">edit</el-button>
                <el-button
                  size="mini"
                  type="danger"
                  @click="delteAccount(scope.$index, scope)">delete</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>


        <div v-if="showOfName == 'aggregationAccount'">
          <div style="background-color: #FFF;padding:16px;margin:8px 0;">
            <H2>aggregation</H2>
            <el-row>
              <el-col :span="2" style="margin:10px">ageRange:</el-col>
              <el-col :span="16">
                <el-slider
                  @change="changeAccoUntFilter"
                  v-model="ageValue"
                  range
                  show-stops
                  :max="100">
                </el-slider>
              </el-col>
            </el-row>
            <el-row style="margin:16px 0">
              <el-col :span="2">genderAggregation:</el-col>
              <el-col :span="4">
                <el-switch
                  @change="getAggregationDate"
                  v-model="showAggregation"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </el-col>
              <el-col :span="2">SUM:</el-col>
              <el-col :span="4">
                <el-switch
                  v-model="isSum"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </el-col>
            </el-row>
          </div>
          <el-table :data="tableData" v-if="showAggregation" :show-summary="isSum" sum-text="sumConut">
            <el-table-column prop="gender" label="gender" >
            </el-table-column>
            <el-table-column prop="count" label="count">
            </el-table-column>
          </el-table>
          <el-table :data="tableData" v-else :show-summary="isSum" sum-text="sumAge">
            <el-table-column prop="accountId" label="accountID" >
            </el-table-column>
            <el-table-column prop="accountName" label="accountName">
            </el-table-column>
            <el-table-column prop="gender" label="gender" >
            </el-table-column>
            <el-table-column prop="registerDate" label="registerDate">
            </el-table-column>
            <el-table-column prop="birthDate" label="birthDate">
            </el-table-column>
            <el-table-column prop="age" label="age">
            </el-table-column>
          </el-table>
        </div>


        <el-table :data="tableData" v-if="showOfName == 'membership'">
          <el-table-column prop="membershipID" label="membershipID" >
          </el-table-column>
          <el-table-column prop="status" label="status">
          </el-table-column>
          <el-table-column prop="feePerMonth" label="feePerMonth" >
          </el-table-column>
          <el-table-column prop="dataJoined" label="dataJoined">
          </el-table-column>
          <el-table-column prop="accountID" label="accountID">
          </el-table-column>
        </el-table>

        <el-table :data="tableData" v-if="showOfName == 'division'">
          <el-table-column prop="accountName" label="accountName">
            </el-table-column>
        </el-table>

        
        <div v-if="showOfName == 'insertUserAccount'">
          <el-row style="margin:16px 0">
            <el-col :span = "3">accountName:</el-col>
            <el-col :span = "3">
              <el-input v-model="insertUserAccount.accountName"></el-input>
            </el-col>
          </el-row >
          <el-row>
            <el-col :span = "3">gender:</el-col>
            <el-col :span = "3">
              <el-select v-model="insertUserAccount.gender" placeholder="gender">
                <el-option
                  key="male"
                  label="male"
                  value="male">
                </el-option>
                <el-option
                  key="female"
                  label="female"
                  value="female">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">registerDate:</el-col>
            <el-col :span = "3">
              <el-date-picker
                v-model="insertUserAccount.registerDate"
                type="date"
                placeholder="date">
              </el-date-picker>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">birthDate:</el-col>
            <el-col :span = "3">
              <el-date-picker
                v-model="insertUserAccount.birthDate"
                type="date"
                placeholder="date">
              </el-date-picker>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">age:</el-col>
            <el-col :span = "3">
              <el-input v-model="insertUserAccount.age"></el-input>
            </el-col>
          </el-row>
          <el-row>
            <el-button @click="insertAccount(insertUserAccount)">
              insert
            </el-button>
          </el-row>
        </div>
        <div v-if="showOfName == 'updateUserAccount'">
          <el-row style="margin:16px 0">
            <el-col :span = "3">accountID:</el-col>
            <el-col :span = "3">
              <span>{{ insertUserAccount.accountId }}</span>
            </el-col>
          </el-row >
          <el-row style="margin:16px 0">
            <el-col :span = "3">accountName:</el-col>
            <el-col :span = "3">
              <el-input v-model="insertUserAccount.accountName"></el-input>
            </el-col>
          </el-row >
          <el-row>
            <el-col :span = "3">gender:</el-col>
            <el-col :span = "3">
              <el-select v-model="insertUserAccount.gender" placeholder="gender">
                <el-option
                  key="male"
                  label="male"
                  value="male">
                </el-option>
                <el-option
                  key="female"
                  label="female"
                  value="female">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">registerDate:</el-col>
            <el-col :span = "3">
              <el-date-picker
                v-model="insertUserAccount.registerDate"
                type="date"
                placeholder="date">
              </el-date-picker>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">birthDate:</el-col>
            <el-col :span = "3">
              <el-date-picker
                v-model="insertUserAccount.birthDate"
                type="date"
                placeholder="date">
              </el-date-picker>
            </el-col>
          </el-row>
          <el-row style="margin:16px 0">
            <el-col :span = "3">age:</el-col>
            <el-col :span = "3">
              <el-input v-model="insertUserAccount.age"></el-input>
            </el-col>
          </el-row>
          <el-row>
            <el-button @click="updateAccount(insertUserAccount)">
              update
            </el-button>
          </el-row>
        </div>
        <div v-if="showOfName == 'joinTable'">
          <el-card class="box-card">
            <div style="background-color: #FFF;padding:16px;margin:8px 0;">
              <H2>Division and Join and Projection</H2>
              <el-row>
                <el-col :span="2" style="margin:10px">age:</el-col>
                <el-col :span="16">
                  <el-slider
                    @change="changeAccoUntFilter"
                    v-model="ageValue"
                    range
                    show-stops
                    :max="100">
                  </el-slider>
                </el-col>
              </el-row>
              <el-row style="margin:16px 0">
                <el-col :span="2">gender:</el-col>
                <el-col :span="4">
                  <el-checkbox-group @change="changeAccoUntFilter" v-model="genderValue" style="float: left;">
                    <el-checkbox label="male"></el-checkbox>
                    <el-checkbox label="female"></el-checkbox>
                  </el-checkbox-group>
                </el-col>
              </el-row>
            </div>
            <el-checkbox-group @click="getJoinTableData" v-model="joinColList">
              <el-checkbox label="accountId"></el-checkbox>
              <el-checkbox label="gender"></el-checkbox>
              <el-checkbox label="registerDate"></el-checkbox>
              <el-checkbox label="birthDate"></el-checkbox>
              <el-checkbox label="age"></el-checkbox>
              <el-checkbox label="accountName"></el-checkbox>
              <el-checkbox label="membershipID"></el-checkbox>
              <el-checkbox label="status"></el-checkbox>
              <el-checkbox label="feePerMonth"></el-checkbox>
              <el-checkbox label="dataJoined"></el-checkbox>
            </el-checkbox-group>
          </el-card>
          <el-table :data="tableData" >
            <el-table-column v-for="col in joinColList" :key="col" :prop="col" :label="col">  
            </el-table-column>
          </el-table>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getAccountData, 
          getMembershipData, 
          selectionUserAccountData, 
          delteAccount, 
          insertAccount, 
          updateAccount, 
          queryAggregationAccountData, 
          getDivision,
          getJoinTableData } from '@/api/welcome';

export default {
  name: 'HelloWorld',
  props: {
    msg: String,
  },
  mixins: [
  ],
  data() {
    return {
      conheight: {
        height: '',
      },
      joinColList: ['accountId','gender','registerDate','birthDate','age','accountName','membershipID','status','feePerMonth','dataJoined'],
      insertUserAccount: {accountId:'',gender:'',registerDate:'',birthDate:'',age:'',accountName:''},
      requestData: {type:'',max:'',min:'',gender: '',gameId: '',acconutId: ''},
      showOfName: '',
      showAggregation: false,
      isSum:false,
      ageValue:[0, 100],
      genderValue: ['male','female'],
      tableData: []
    };
  },
  created() {
    window.addEventListener('resize', this.getHeight);
    this.getHeight();
  },
  mounted() {
    // this.getImgData();
  },
  methods: {
    getHeight() {
      // this.conheight.height = `${window.innerHeight - 170}px`;
      this.conheight.height = `${window.innerHeight * 0.83 - 32}px`;
    },
    edit(acconutId) {
      this.showOfName = 'updateUserAccount'
      this.insertUserAccount.accountId = acconutId
    },
    show(name) {
      this.showOfName = name;
      if (name == 'userAccount') {
        this.getAccountData();
      }
      if (name == 'membership') {
        this.getMembershipData();
      }      
      if (name == 'aggregationAccount') {
        this.getAggregationDate();
      }
      if (name == 'joinTable') {
        this.getJoinTableData();
      }
      if (name == 'division') {
        this.getDivision();
      }
    },
    changeAccoUntFilter() {
      this.selectionUserAccountData();
    },
    getAggregationDate() {
      if (this.showAggregation === true) {
        const params = {max:this.ageValue[1],min:this.ageValue[0],gender:true}
        queryAggregationAccountData(params)
          .then(async (res) => {
            // console.log(res);
            this.tableData = res;
            
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        this.genderValue = ['female','male']
        this.selectionUserAccountData();
      }
    },
    selectionUserAccountData() {
      const gender = this.getGenderString()
      const params = {type:"age",max:this.ageValue[1],min:this.ageValue[0],gender:gender}
      selectionUserAccountData(params)
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getAccountData() {
      getAccountData()
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getMembershipData() {
      getMembershipData()
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getDivision() {
      getDivision()
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getGenderString(){
      let gender = "''"
      console.log(this.genderValue)
      if (this.genderValue.length >1) {
        gender = "'"+this.genderValue[0] + "','" + this.genderValue[1] + "'"
      }
      if (this.genderValue.length == 1) {
        gender =  "'" + this.genderValue[0] + "'"
      }
      return gender
    },
    getJoinTableData() {
      const gender = this.getGenderString()
      const params = {type:"age",max:this.ageValue[1],min:this.ageValue[0],gender:gender,column:this.joinColList}
      getJoinTableData(params)
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getAggregationAccountData() {
      queryAggregationAccountData(this.requestData)
        .then(async (res) => {
          this.tableData = res;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    editAccount(index,id) {
      const accountId = this.tableData[index].accountID
      this.edit(accountId);
    },
    delteAccount(index,id) {
      console.log(this.tableData[index]);
      const accountId = {acconutId:this.tableData[index].accountId}
      delteAccount(accountId)
      .then()
      .catch((err) => {
        console.log(err);
      });
      this.getAccountData();
    },
    insertAccount(insertUserAccount) {
      insertAccount(insertUserAccount)
      .then(
        this.insertAccount = {}
      )
      .catch((err) => {
        console.log(err);
      });
      this.show("userAccount")
    },
    updateAccount(insertUserAccount) {
      updateAccount(insertUserAccount)
      .then(
        this.insertAccount = {}
      )
      .catch((err) => {
        console.log(err);
      });
      this.show("userAccount")
    }
  },
};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
</style>
