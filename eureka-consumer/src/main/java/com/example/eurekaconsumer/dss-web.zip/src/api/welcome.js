import request from '@/plugin/axios';

export function AccountLogin(data) {
  return request({
    url: '/login',
    method: 'post',
    data,
  });
}

export function test(data) {
  return request({
    url: '/api',
    method: 'post',
    data,
  });
}

export function getAccountData() {
  return request({
    url: '/api/queryUserAccountData',
    method: 'get',
  });
}

export function getMembershipData() {
  return request({
    url: '/api/queryMembershipData',
    method: 'get',
  });
}

export function selectionUserAccountData(data) {
  return request({
    url: '/api/selectionUserAccountData',
    method: 'post',
    data,
  });
}

