<template>
  <el-container style=" border: 1px solid #eee">
    <el-aside width="240px" style="background-color: #FFF;margin:0 4px;padding:16px;
    ">
      <el-menu :default-openeds="['1', '2', '3']">
        <el-submenu index="1">
          <template slot="title"><i class="el-icon-s-unfold"></i>select</template>
          <el-menu-item-group>
            <el-menu-item index="1-1" @click="show('userAccount')">Account</el-menu-item>
            <el-menu-item index="1-2" @click="show('membership')">Membership</el-menu-item>
            <el-menu-item index="1-3" @click="show('developer')">developer</el-menu-item>
            <el-menu-item index="1-4" @click="show('game')">game</el-menu-item>

          </el-menu-item-group>
          <el-submenu index="1-4">
            <template slot="title">Aggregation</template>
            <el-menu-item index="1-4-1">accountGroup</el-menu-item>
          </el-submenu>
        </el-submenu>
        <el-submenu index="2">
          <template slot="title"><i class="el-icon-upload"></i>insert</template>
          <el-menu-item-group>
           <el-menu-item index="1-1" @click="show('userAccount')">Account</el-menu-item>
           <el-menu-item index="1-2" @click="show('membership')">Membership</el-menu-item>
           <el-menu-item index="1-3" @click="show('developer')">developer</el-menu-item>
           <el-menu-item index="1-4" @click="show('game')">game</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <!-- <el-submenu index="3">
          <template slot="title"><i class="el-icon-setting"></i>导航三</template>
          <el-menu-item-group>
            <template slot="title">分组一</template>
            <el-menu-item index="3-1">选项1</el-menu-item>
            <el-menu-item index="3-2">选项2</el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group title="分组2">
            <el-menu-item index="3-3">选项3</el-menu-item>
          </el-menu-item-group>
          <el-submenu index="3-4">
            <template slot="title">选项4</template>
            <el-menu-item index="3-4-1">选项4-1</el-menu-item>
          </el-submenu>
        </el-submenu> -->
      </el-menu>
    </el-aside>
    
    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>查看</el-dropdown-item>
            <el-dropdown-item>新增</el-dropdown-item>
            <el-dropdown-item>删除</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span>admin</span>
      </el-header>
      
      <el-main>
        <div v-if="showOfName == 'userAccount'">
          <div style="background-color: #FFF;padding:16px;margin:8px 0;">
            <H2>selection</H2>
            <el-row>
              <el-col :span="2" style="margin:10px">age:</el-col>
              <el-col :span="16">
                <el-slider
                  @change="changeAccoUntFilter"
                  v-model="ageValue"
                  range
                  show-stops
                  :max="100">
                </el-slider>
              </el-col>
            </el-row>
            <el-row style="margin:16px">
              <el-col :span="2">gender:</el-col>
              <el-col :span="4">
                <el-checkbox-group @change="changeAccoUntFilter" v-model="genderValue" style="float: left;">
                  <el-checkbox label="male"></el-checkbox>
                  <el-checkbox label="female"></el-checkbox>
                </el-checkbox-group>
              </el-col>
            </el-row>
          </div>
          
          <el-table :data="tableData" >
            <el-table-column prop="accountID" label="accountID" >
            </el-table-column>
            <el-table-column prop="accountName" label="accountName">
            </el-table-column>
            <el-table-column prop="gender" label="gender" >
            </el-table-column>
            <el-table-column prop="registerDate" label="registerDate">
            </el-table-column>
            <el-table-column prop="birthDate" label="birthDate">
            </el-table-column>
            <el-table-column prop="age" label="age">
            </el-table-column>
            <el-table-column label="operating">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="handleEdit(scope.$index, scope.accountID)">edit</el-button>
                <el-button
                  size="mini"
                  type="danger"
                  @click="handleDelete(scope.$index, scope.accountID)">delete</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <el-table :data="tableData" v-if="showOfName == 'membership'">
          <el-table-column prop="membershipID" label="membershipID" >
          </el-table-column>
          <el-table-column prop="status" label="status">
          </el-table-column>
          <el-table-column prop="feePerMonth" label="feePerMonth" >
          </el-table-column>
          <el-table-column prop="dataJoined" label="dataJoined">
          </el-table-column>
          <el-table-column prop="accountID" label="accountID">
          </el-table-column>
        </el-table>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getAccountData, getMembershipData, selectionUserAccountData } from '@/api/welcome';

export default {
  name: 'HelloWorld',
  props: {
    msg: String,
  },
  mixins: [
  ],
  data() {
    return {
      row: 1,
      row2: 1,
      urls: [],
      count: 0,
      reUrls: [],
      newChecked: '',
      checkedUrls: [],
      conheight: {
        height: '',
      },
      showOfName: '',
      ageValue:[0, 100],
      genderValue: ['male','female'],
      tableData: [{
          accountID: '2016-05-02',
          accountName: '王小虎',
          membershipID: '上海市普陀区金沙江路 1518 弄',
        }, {
          accountID: '2016-05-04',
          accountName: '王小虎',
          membershipID: '上海市普陀区金沙江路 1518 弄'
        }, {
          accountID: '2016-05-01',
          accountName: '王小虎',
          membershipID: '上海市普陀区金沙江路 1518 弄',
        }]
    };
  },
  created() {
    window.addEventListener('resize', this.getHeight);
    this.getHeight();
  },
  mounted() {
    // this.getImgData();
  },
  methods: {
    getHeight() {
      // this.conheight.height = `${window.innerHeight - 170}px`;
      this.conheight.height = `${window.innerHeight * 0.83 - 32}px`;
    },
    show(name) {
      this.showOfName = name;
      if (name == 'userAccount') {
        this.getAccountData();
      }
      if (name == 'membership') {
        this.getMembershipData();
      }
    },
    changeAccoUntFilter() {
      this.selectionUserAccountData();
    },
    selectionUserAccountData() {
      let gender = "''"
      console.log(this.genderValue)
      if (this.genderValue.length >1) {
        gender = "'"+this.genderValue[0] + "','" + this.genderValue[1] + "'"
      }
      if (this.genderValue.length == 1) {
        gender =  "'" + this.genderValue[0] + "'"
      }
      const params = {type:"age",max:this.ageValue[1],min:this.ageValue[0],gender:gender}
      selectionUserAccountData(params)
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getAccountData() {
      getAccountData()
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getMembershipData() {
      getMembershipData()
        .then(async (res) => {
          // console.log(res);
          this.tableData = res;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getDist(idList) {
      // const data = { id: imgId };
      getImgDist({ idList })
        .then(async (res) => {
          let i = 0;
          this.reUrls = res.map((o) => {
            o.src = `http://${o.local}/img/50/${o.name}`;
            o.rowId = i++;
            o.distances = parseInt(o.distances);
            return o;
          });
          // console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getDist2(imgIdA, imgIdB) {
      // const data = { id: imgId };
      getImgDistTwo({ imgIdA, imgIdB })
        .then(async (res) => {
          this.reUrls = res.map((o) => { o.src = `http://${o.local}/img/50/${o.name}`; return o; });
          // console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
  watch: {
    screenHeight(val) {
      // 为了避免频繁触发resize函数导致页面卡顿，使用定时器
      if (!this.timer) {
        // 一旦监听到的screenWidth值改变，就将其重新赋给data里的screenWidth
        this.screenHeight = val;
        this.timer = true;
        const that = this;
        setTimeout(() => {
          // 打印screenWidth变化的值
          console.log(that.screenHeight);
          that.timer = false;
        }, 400);
      }
    },
  },
};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {

  }
</style>
