import request from '@/plugin/axios';

export function AccountLogin(data) {
  return request({
    url: '/login',
    method: 'post',
    data,
  });
}

export function test(data) {
  return request({
    url: '/api',
    method: 'post',
    data,
  });
}

export function getAccountData() {
  return request({
    url: '/api/queryUserAccountData',
    method: 'get',
  });
}

export function getMembershipData() {
  return request({
    url: '/api/queryMembershipData',
    method: 'get',
  });
}

export function selectionUserAccountData(data) {
  return request({
    url: '/api/selectionUserAccountData',
    method: 'post',
    data,
  });
}

export function delteAccount(data) {
  return request({
    url: '/api/delteAccount',
    method: 'post',
    data,
  });
}

export function insertAccount(data) {
  return request({
    url: '/api/insertAccount',
    method: 'post',
    data,
  });
}

export function updateAccount(data) {
  return request({
    url: '/api/updateAccount',
    method: 'post',
    data,
  });
}

export function queryAggregationAccountData(data) {
  return request({
    url: '/api/queryAggregationAccountData',
    method: 'post',
    data,
  });
}

export function getJoinTableData(data) {
  return request({
    url: '/api/getJoinTableData',
    method: 'post',
    data,
  });
}

export function getDivision() {
  return request({
    url: '/api/queryDivision',
    method: 'get',
  });
}